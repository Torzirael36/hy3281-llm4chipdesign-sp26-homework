module testbench;
    // Declare signals
    reg [3:0] a;
    reg [3:0] b;
    wire [3:0] sum;
    wire carry;

    // Instantiate the module under test
    adder4bit uut (
        .a(a),
        .b(b),
        .sum(sum),
        .carry(carry)
    );

    integer passed_tests;
    integer failed_tests;
    
    initial begin
        passed_tests = 0;
        failed_tests = 0;

        // Test patterns
        a = 4'b0000; b = 4'b0000; #10; $display("Test 1: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b0000) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 0000)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b0000; b = 4'b1111; #10; $display("Test 2: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1111) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1111)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b1111; b = 4'b0000; #10; $display("Test 3: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1111) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1111)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b1111; b = 4'b1111; #10; $display("Test 4: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1110) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1110)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b1) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 1)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b1000; b = 4'b1000; #10; $display("Test 5: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b0000) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 0000)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b1) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 1)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b0111; b = 4'b0001; #10; $display("Test 6: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1000) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1000)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b0001; b = 4'b0111; #10; $display("Test 7: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1000) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1000)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b0100; b = 4'b0100; #10; $display("Test 8: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1000) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1000)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b0011; b = 4'b0101; #10; $display("Test 9: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1000) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1000)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b0110; b = 4'b0011; #10; $display("Test 10: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1001) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1001)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b1010; b = 4'b0101; #10; $display("Test 11: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1111) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1111)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        a = 4'b1100; b = 4'b0011; #10; $display("Test 12: a=%b b=%b", a, b);
        #10;
        if (sum === 4'b1111) begin
            $display("Sum: %b ✓", sum);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Sum: %b ✗ (Expected: 1111)", sum);
            failed_tests = failed_tests + 1;
        end
        if (carry === 1'b0) begin
            $display("Carry: %b ✓", carry);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Carry: %b ✗ (Expected: 0)", carry);
            failed_tests = failed_tests + 1;
        end

        $display("Test Summary:");
        $display("Total Tests Run: %d", passed_tests + failed_tests);
        $display("Number of Tests Passed: %d", passed_tests);
        $display("Number of Tests Failed: %d", failed_tests);

        $finish;
    end
endmodule