module testbench;
    // Declare signals
    reg [3:0] a;
    reg [3:0] b;
    wire [3:0] sum;
    wire carry;

    // Instantiate the module under test
    adder4bit uut (
        .a(a),
        .b(b),
        .sum(sum),
        .carry(carry)
    );

    initial begin
        // Test patterns
        a = 4'b0000; b = 4'b0000; #10; $display("Test 1: a=%b b=%b", a, b);
        a = 4'b0000; b = 4'b1111; #10; $display("Test 2: a=%b b=%b", a, b);
        a = 4'b1111; b = 4'b0000; #10; $display("Test 3: a=%b b=%b", a, b);
        a = 4'b1111; b = 4'b1111; #10; $display("Test 4: a=%b b=%b", a, b);
        a = 4'b1000; b = 4'b1000; #10; $display("Test 5: a=%b b=%b", a, b);
        a = 4'b0111; b = 4'b0001; #10; $display("Test 6: a=%b b=%b", a, b);
        a = 4'b0001; b = 4'b0111; #10; $display("Test 7: a=%b b=%b", a, b);
        a = 4'b0100; b = 4'b0100; #10; $display("Test 8: a=%b b=%b", a, b);
        
        // Random value tests
        a = 4'b0011; b = 4'b0101; #10; $display("Test 9: a=%b b=%b", a, b);
        a = 4'b0110; b = 4'b0011; #10; $display("Test 10: a=%b b=%b", a, b);
        a = 4'b1010; b = 4'b0101; #10; $display("Test 11: a=%b b=%b", a, b);
        a = 4'b1100; b = 4'b0011; #10; $display("Test 12: a=%b b=%b", a, b);

        $finish;
    end
endmodule