def sat_adder4_golden(a, b):
    # Ensure inputs are within 4-bit range
    a = a & 0xF
    b = b & 0xF
    
    # Compute the sum
    result = a + b
    
    # Saturate the result to 15 if it exceeds 15
    if result > 15:
        result = 15
    
    # Return the result as a dictionary
    return {'sum': result}

# Test cases
test_cases = [
    (0, 0),  # 0 + 0 = 0
    (1, 2),  # 1 + 2 = 3
    (7, 8),  # 7 + 8 = 15 (saturate)
    (15, 1), # 15 + 1 = 15 (saturate)
    (15, 15),# 15 + 15 = 15 (saturate)
    (3, 4),  # 3 + 4 = 7
    (6, 9),  # 6 + 9 = 15 (saturate)
    (8, 7),  # 8 + 7 = 15 (saturate)
    (5, 5),  # 5 + 5 = 10
    (10, 5), # 10 + 5 = 15 (saturate)
    (4, 4),  # 4 + 4 = 8
    (2, 3),  # 2 + 3 = 5
    (12, 3), # 12 + 3 = 15 (saturate)
    (9, 6),  # 9 + 6 = 15 (saturate)
    (11, 4), # 11 + 4 = 15 (saturate)
    (13, 2), # 13 + 2 = 15 (saturate)
    (14, 1), # 14 + 1 = 15 (saturate)
    (0, 15), # 0 + 15 = 15
    (7, 7),  # 7 + 7 = 14
    (5, 10)  # 5 + 10 = 15 (saturate)
]

# Run test cases
for a, b in test_cases:
    result = sat_adder4_golden(a, b)
    print(f"sat_adder4_golden({a}, {b}) = {result}")