module tb_sat_adder4;
    // Declare signals
    reg [3:0] a;
    reg [3:0] b;
    wire [3:0] sum;

    // Instantiate the module under test
    sat_adder4 uut (
        .a(a),
        .b(b),
        .sum(sum)
    );

    initial begin
    integer passed_tests = 0;
    integer failed_tests = 0;

        // Test pattern 1: Corner case 0 + 0
        a = 4'b0000; b = 4'b0000;
        #10 $display("Test 1: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 2: Small values 1 + 2
        a = 4'b0001; b = 4'b0010;
        #10 $display("Test 2: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 3: Small values 3 + 4
        a = 4'b0011; b = 4'b0100;
        #10 $display("Test 3: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 4: Boundary case 7 + 8
        a = 4'b0111; b = 4'b1000;
        #10 $display("Test 4: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 5: Overflow case 15 + 1
        a = 4'b1111; b = 4'b0001;
        #10 $display("Test 5: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 6: Overflow case 15 + 15
        a = 4'b1111; b = 4'b1111;
        #10 $display("Test 6: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 7: Random values 5 + 10
        a = 4'b0101; b = 4'b1010;
        #10 $display("Test 7: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 8: Random values 9 + 7
        a = 4'b1001; b = 4'b0111;
        #10 $display("Test 8: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 9: Random values 2 + 13
        a = 4'b0010; b = 4'b1101;
        #10 $display("Test 9: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 10: Random values 6 + 9
        a = 4'b0110; b = 4'b1001;
        #10 $display("Test 10: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 11: Random values 0 + 15
        a = 4'b0000; b = 4'b1111;
        #10 $display("Test 11: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 12: Edge case 8 + 8
        a = 4'b1000; b = 4'b1000;
        #10 $display("Test 12: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 13: Random values 4 + 4
        a = 4'b0100; b = 4'b0100;
        #10 $display("Test 13: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 14: Edge case 15 + 0
        a = 4'b1111; b = 4'b0000;
        #10 $display("Test 14: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 15: Random values 7 + 6
        a = 4'b0111; b = 4'b0110;
        #10 $display("Test 15: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 16: Random values 14 + 1
        a = 4'b1110; b = 4'b0001;
        #10 $display("Test 16: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 17: Random values 3 + 10
        a = 4'b0011; b = 4'b1010;
        #10 $display("Test 17: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 18: Random values 12 + 3
        a = 4'b1100; b = 4'b0011;
        #10 $display("Test 18: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 19: Random values 11 + 5
        a = 4'b1011; b = 4'b0101;
        #10 $display("Test 19: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        // Test pattern 20: Random values 13 + 2
        a = 4'b1101; b = 4'b0010;
        #10 $display("Test 20: a = %b, b = %b, sum = %b", a, b, sum);
        #10; // Wait for outputs to settle

        $finish;

    // Test Summary
    $display("\n========== Test Summary ==========");
    $display("Total Tests: %0d", passed_tests + failed_tests);
    $display("Passed: %0d", passed_tests);
    $display("Failed: %0d", failed_tests);
    $display("==================================\n");

    end
endmodule