module tb_mux2to1;
    // Declare inputs as regs and outputs as wires
    reg a;
    reg b;
    reg sel;
    wire y;

    // Instantiate the mux2to1 module
    mux2to1 uut (
        .a(a),
        .b(b),
        .sel(sel),
        .y(y)
    );

    initial begin
        integer passed_tests = 0;
        integer failed_tests = 0;
        
        // Test Case 1: a=0, b=0, sel=0
        a = 0; b = 0; sel = 0;
        #10;
        $display("Test 1: a=%b, b=%b, sel=%b, y=%b", a, b, sel, y);
        #10;
        if (y === 0) begin
            $display("Test 1: ✓ Expected y=0, Got y=%b", y);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Test 1: ✗ Expected y=0, Got y=%b", y);
            failed_tests = failed_tests + 1;
        end

        // Test Case 2: a=0, b=0, sel=1
        a = 0; b = 0; sel = 1;
        #10;
        $display("Test 2: a=%b, b=%b, sel=%b, y=%b", a, b, sel, y);
        #10;
        if (y === 0) begin
            $display("Test 2: ✓ Expected y=0, Got y=%b", y);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Test 2: ✗ Expected y=0, Got y=%b", y);
            failed_tests = failed_tests + 1;
        end

        // Test Case 3: a=0, b=1, sel=0
        a = 0; b = 1; sel = 0;
        #10;
        $display("Test 3: a=%b, b=%b, sel=%b, y=%b", a, b, sel, y);
        #10;
        if (y === 0) begin
            $display("Test 3: ✓ Expected y=0, Got y=%b", y);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Test 3: ✗ Expected y=0, Got y=%b", y);
            failed_tests = failed_tests + 1;
        end

        // Test Case 4: a=0, b=1, sel=1
        a = 0; b = 1; sel = 1;
        #10;
        $display("Test 4: a=%b, b=%b, sel=%b, y=%b", a, b, sel, y);
        #10;
        if (y === 1) begin
            $display("Test 4: ✓ Expected y=1, Got y=%b", y);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Test 4: ✗ Expected y=1, Got y=%b", y);
            failed_tests = failed_tests + 1;
        end

        // Test Case 5: a=1, b=0, sel=0
        a = 1; b = 0; sel = 0;
        #10;
        $display("Test 5: a=%b, b=%b, sel=%b, y=%b", a, b, sel, y);
        #10;
        if (y === 1) begin
            $display("Test 5: ✓ Expected y=1, Got y=%b", y);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Test 5: ✗ Expected y=1, Got y=%b", y);
            failed_tests = failed_tests + 1;
        end

        // Test Case 6: a=1, b=0, sel=1
        a = 1; b = 0; sel = 1;
        #10;
        $display("Test 6: a=%b, b=%b, sel=%b, y=%b", a, b, sel, y);
        #10;
        if (y === 0) begin
            $display("Test 6: ✓ Expected y=0, Got y=%b", y);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Test 6: ✗ Expected y=0, Got y=%b", y);
            failed_tests = failed_tests + 1;
        end

        // Test Case 7: a=1, b=1, sel=0
        a = 1; b = 1; sel = 0;
        #10;
        $display("Test 7: a=%b, b=%b, sel=%b, y=%b", a, b, sel, y);
        #10;
        if (y === 1) begin
            $display("Test 7: ✓ Expected y=1, Got y=%b", y);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Test 7: ✗ Expected y=1, Got y=%b", y);
            failed_tests = failed_tests + 1;
        end

        // Test Case 8: a=1, b=1, sel=1
        a = 1; b = 1; sel = 1;
        #10;
        $display("Test 8: a=%b, b=%b, sel=%b, y=%b", a, b, sel, y);
        #10;
        if (y === 1) begin
            $display("Test 8: ✓ Expected y=1, Got y=%b", y);
            passed_tests = passed_tests + 1;
        end else begin
            $display("Test 8: ✗ Expected y=1, Got y=%b", y);
            failed_tests = failed_tests + 1;
        end

        // Test summary
        $display("Test Summary: Total=%0d, Passed=%0d, Failed=%0d", passed_tests + failed_tests, passed_tests, failed_tests);

        // Finish the simulation
        $finish;
    end
endmodule