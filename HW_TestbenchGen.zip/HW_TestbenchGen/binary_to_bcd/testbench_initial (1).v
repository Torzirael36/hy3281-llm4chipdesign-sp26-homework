module testbench;
    reg [4:0] binary_input;
    wire [7:0] bcd_output;

    // Instantiate the module under test
    binary_to_bcd_converter uut (
        .binary_input(binary_input),
        .bcd_output(bcd_output)
    );

    initial begin
        // Test case 1: Minimum boundary value
        binary_input = 5'b00000;
        #10;
        $display("Test 1 - binary_input: %b", binary_input);

        // Test case 2: Maximum boundary value
        binary_input = 5'b11111;
        #10;
        $display("Test 2 - binary_input: %b", binary_input);

        // Test case 3: Typical use case - middle value
        binary_input = 5'b01101; // 13 in decimal
        #10;
        $display("Test 3 - binary_input: %b", binary_input);

        // Test case 4: Edge case - small non-zero value
        binary_input = 5'b00001;
        #10;
        $display("Test 4 - binary_input: %b", binary_input);

        // Test case 5: Edge case - one less than max
        binary_input = 5'b11110;
        #10;
        $display("Test 5 - binary_input: %b", binary_input);

        // Test case 6: Random value
        binary_input = 5'b10101;
        #10;
        $display("Test 6 - binary_input: %b", binary_input);

        // Test case 7: Random value
        binary_input = 5'b01010;
        #10;
        $display("Test 7 - binary_input: %b", binary_input);

        // Test case 8: Random value
        binary_input = 5'b00111;
        #10;
        $display("Test 8 - binary_input: %b", binary_input);

        // Test case 9: Corner case - power of two
        binary_input = 5'b10000;
        #10;
        $display("Test 9 - binary_input: %b", binary_input);

        // Test case 10: Another typical case
        binary_input = 5'b01001; // 9 in decimal
        #10;
        $display("Test 10 - binary_input: %b", binary_input);

        $finish;
    end
endmodule