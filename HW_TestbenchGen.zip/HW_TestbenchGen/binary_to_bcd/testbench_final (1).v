module testbench;
    reg [4:0] binary_input;
    wire [7:0] bcd_output;
    integer passed_tests = 0;
    integer failed_tests = 0;

    // Instantiate the module under test
    binary_to_bcd_converter uut (
        .binary_input(binary_input),
        .bcd_output(bcd_output)
    );

    initial begin
        // Test case 1: Minimum boundary value
        binary_input = 5'b00000;
        #10;
        $display("Test 1 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00000000) begin
            $display("✓ bcd_output: %b (expected: 00000000)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00000000)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 2: Maximum boundary value
        binary_input = 5'b11111;
        #10;
        $display("Test 2 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00110001) begin
            $display("✓ bcd_output: %b (expected: 00110001)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00110001)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 3: Typical use case - middle value
        binary_input = 5'b01101; // 13 in decimal
        #10;
        $display("Test 3 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00010011) begin
            $display("✓ bcd_output: %b (expected: 00010011)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00010011)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 4: Edge case - small non-zero value
        binary_input = 5'b00001;
        #10;
        $display("Test 4 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00000001) begin
            $display("✓ bcd_output: %b (expected: 00000001)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00000001)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 5: Edge case - one less than max
        binary_input = 5'b11110;
        #10;
        $display("Test 5 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00110000) begin
            $display("✓ bcd_output: %b (expected: 00110000)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00110000)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 6: Random value
        binary_input = 5'b10101;
        #10;
        $display("Test 6 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00100001) begin
            $display("✓ bcd_output: %b (expected: 00100001)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00100001)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 7: Random value
        binary_input = 5'b01010;
        #10;
        $display("Test 7 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00010000) begin
            $display("✓ bcd_output: %b (expected: 00010000)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00010000)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 8: Random value
        binary_input = 5'b00111;
        #10;
        $display("Test 8 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00000111) begin
            $display("✓ bcd_output: %b (expected: 00000111)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00000111)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 9: Corner case - power of two
        binary_input = 5'b10000;
        #10;
        $display("Test 9 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00010110) begin
            $display("✓ bcd_output: %b (expected: 00010110)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00010110)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test case 10: Another typical case
        binary_input = 5'b01001; // 9 in decimal
        #10;
        $display("Test 10 - binary_input: %b", binary_input);
        #10;
        if (bcd_output === 8'b00001001) begin
            $display("✓ bcd_output: %b (expected: 00001001)", bcd_output);
            passed_tests = passed_tests + 1;
        end else begin
            $display("✗ bcd_output: %b (expected: 00001001)", bcd_output);
            failed_tests = failed_tests + 1;
        end

        // Test Summary
        $display("Test Summary:");
        $display("Total tests run: %0d", passed_tests + failed_tests);
        $display("Number passed: %0d", passed_tests);
        $display("Number failed: %0d", failed_tests);

        $finish;
    end
endmodule