
module sat_adder4 (
    input  wire [3:0] a,
    input  wire [3:0] b,
    output wire [3:0] sum
);
    wire [4:0] raw_sum;
    assign raw_sum = a + b;
    assign sum = (raw_sum > 5'd15) ? 4'd15 : raw_sum[3:0];
endmodule
