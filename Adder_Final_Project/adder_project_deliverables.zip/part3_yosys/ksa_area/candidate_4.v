module KSA8(output [7:0] sum, output cout, input [7:0] a, b);

  wire [7:0] g, p, c;
  wire cin = 1'b0;

  // Generate propagate and generate signals
  assign g = a & b;
  assign p = a ^ b;

  // Level 1
  wire [3:0] g1;
  assign g1[0] = g[1] | (p[1] & g[0]);
  assign g1[1] = g[3] | (p[3] & g[2]);
  assign g1[2] = g[5] | (p[5] & g[4]);
  assign g1[3] = g[7] | (p[7] & g[6]);

  // Level 2
  wire g2_0, g2_1;
  assign g2_0 = g1[1] | (p[3] & g1[0]);
  assign g2_1 = g1[3] | (p[7] & g1[2]);

  // Carry generation
  assign c[0] = cin;
  assign c[1] = g[0];
  assign c[2] = g1[0];
  assign c[3] = g2_0;
  assign c[4] = g1[1];
  assign c[5] = g2_0;
  assign c[6] = g1[2];
  assign c[7] = g2_1;

  // Sum generation
  assign sum = p ^ c;
  assign cout = g2_1;

endmodule