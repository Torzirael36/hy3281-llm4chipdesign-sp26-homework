# Part 3 Step 8: Multi-Start Exploration Analysis

In this step, the optimization loop was launched from multiple different starting architectures rather than a single baseline. The purpose of this experiment was to reduce the risk of converging to a local optimum and to compare how the initial architecture influences the final PPA outcome.

The experiments used different starting architectures and optimization modes:
- KSA8 with area mode
- CLA8 with delay mode
- RCA8 with balanced mode

For each run, the best discovered design was recorded together with its PPA metrics and an LLM-based architectural interpretation.

This comparison highlights two important observations:
1. The starting architecture affects the search trajectory and the kind of solution that the LLM-Yosys loop discovers.
2. Different optimization modes can favor very different tradeoffs between area and delay, even when the top-level function remains the same.

Because the current Colab/Yosys environment does not reliably provide logic_levels, the comparison table records logic levels as N/A when unavailable and uses delay_ps as the practical delay metric instead.