# Part 3 Step 8: Multi-Start Comparison Table

| Starting Architecture | Optimization Mode | Final Cells | Final Logic Levels | Final Area (um^2) | Delay (ps) | Architecture Identified |
|---|---|---:|---:|---:|---:|---|
| KSA8 | area | 32 | N/A | 44.688 | 131.25 | Prefix / Kogge-Stone-like |
| CLA8 | delay | 38 | N/A | 50.274 | 224.01 | Ripple Carry |
| RCA8 | balanced | 37 | N/A | 67.564 | 201.71 | Hybrid RCA/CLA |