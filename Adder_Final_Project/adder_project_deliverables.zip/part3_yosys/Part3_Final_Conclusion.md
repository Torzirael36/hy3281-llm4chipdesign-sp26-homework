# Part 3 Final Conclusion

In Part 3, the LLM-Yosys optimization loop successfully explored multiple adder design variants under three optimization modes: area, delay, and balanced.

The verification results show that the **area-mode** and **balanced-mode** optimized designs are valid final results. Both designs passed:
1. functional simulation with Iverilog, and
2. SAT-based equivalence checking against the original RCA8 baseline in Yosys.

Therefore, these two optimized designs can be accepted as correct optimized implementations.

In contrast, the **delay-mode** design is rejected. Although it achieved better delay-related PPA metrics, it failed functional simulation, indicating that the optimization introduced incorrect adder behavior. This demonstrates an important lesson of LLM-guided hardware optimization: improvements in PPA are only meaningful when functional correctness is preserved.

Overall, this experiment shows that the LLM-Yosys loop can discover useful implementation tradeoffs. In this run:
- **area mode** preserved correctness and maintained a strong low-cost implementation,
- **balanced mode** achieved a better tradeoff between performance and implementation cost while remaining correct,
- **delay mode** pushed optimization too aggressively and produced an invalid design.

Thus, the final accepted optimized results from Part 3 are the **area-mode** and **balanced-mode** designs, while the **delay-mode** design is excluded from the final set of valid solutions.