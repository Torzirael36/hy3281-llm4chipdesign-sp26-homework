// Half Adder
module HA(output sum, cout, input a, b);
  xor (sum, a, b);
  and (cout, a, b);
endmodule

// Full Adder using Half Adders
module gate_FA(output sum, cout, input a, b, cin);
  wire sum1, c1, c2;
  
  HA ha1(sum1, c1, a, b);
  HA ha2(sum, c2, sum1, cin);
  or (cout, c1, c2);
endmodule

// Ripple Carry Adder - 8 bits
module gate(output [7:0] sum, output cout, input [7:0] a, b);
  
  wire [7:0] c;
  
  gate_FA fa0(sum[0], c[0], a[0], b[0], 1'b0);
  gate_FA fa1(sum[1], c[1], a[1], b[1], c[0]);
  gate_FA fa2(sum[2], c[2], a[2], b[2], c[1]);
  gate_FA fa3(sum[3], c[3], a[3], b[3], c[2]);
  gate_FA fa4(sum[4], c[4], a[4], b[4], c[3]);
  gate_FA fa5(sum[5], c[5], a[5], b[5], c[4]);
  gate_FA fa6(sum[6], c[6], a[6], b[6], c[5]);
  gate_FA fa7(sum[7], cout, a[7], b[7], c[6]);
  
endmodule