// Optimized Ripple Carry Adder with Group Propagate and Generate - 8 bits
module RCA8(output [7:0] sum, output cout, input [7:0] a, b);

  wire [7:0] p, g;
  wire [7:0] c;

  // Generate Propagate and Generate signals
  assign p = a ^ b;
  assign g = a & b;

  // Group Propagate and Generate for faster carry calculation
  wire [1:0] P, G;
  assign P[0] = &p[3:0]; // Group propagate for lower 4 bits
  assign G[0] = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (p[3] & p[2] & p[1] & g[0]); // Group generate for lower 4 bits
  assign P[1] = &p[7:4]; // Group propagate for upper 4 bits
  assign G[1] = g[7] | (p[7] & g[6]) | (p[7] & p[6] & g[5]) | (p[7] & p[6] & p[5] & g[4]); // Group generate for upper 4 bits

  // Carry calculation
  assign c[0] = 0;
  assign c[4] = G[0] | (P[0] & c[0]);
  assign c[1] = g[0] | (p[0] & c[0]);
  assign c[2] = g[1] | (p[1] & c[1]);
  assign c[3] = g[2] | (p[2] & c[2]);
  assign c[5] = g[4] | (p[4] & c[4]);
  assign c[6] = g[5] | (p[5] & c[5]);
  assign c[7] = g[6] | (p[6] & c[6]);

  // Sum and Carry Out
  assign sum = p ^ c;
  assign cout = G[1] | (P[1] & c[4]);

endmodule