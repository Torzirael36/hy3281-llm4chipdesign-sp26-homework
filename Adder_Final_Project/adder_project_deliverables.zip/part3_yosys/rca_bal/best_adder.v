// Hybrid Adder - 8 bits
module RCA8(output [7:0] sum, output cout, input [7:0] a, b);

  wire [7:0] p, g;
  wire [7:0] c;

  // Generate Propagate and Generate signals
  assign p = a ^ b;
  assign g = a & b;

  // Carry Generation using a combination of Ripple Carry and Lookahead
  assign c[0] = 0;
  assign c[1] = g[0] | (p[0] & c[0]);
  assign c[2] = g[1] | (p[1] & c[1]);
  assign c[3] = g[2] | (p[2] & c[2]);
  assign c[4] = g[3] | (p[3] & c[3]);
  assign c[5] = g[4] | (p[4] & c[4]);
  assign c[6] = g[5] | (p[5] & c[5]);
  assign c[7] = g[6] | (p[6] & c[6]);

  // Sum and Carry Out
  assign sum = p ^ c;
  assign cout = g[7] | (p[7] & c[7]);

endmodule