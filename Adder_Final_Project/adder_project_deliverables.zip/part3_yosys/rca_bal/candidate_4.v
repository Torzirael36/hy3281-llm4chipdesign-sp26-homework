// Carry Select Adder - 8 bits
module RCA8(output [7:0] sum, output cout, input [7:0] a, b);

  wire [3:0] sum0, sum1, sum2, sum3;
  wire c1, c2, c3, c4, c5, c6, c7;
  wire c1_sel, c2_sel, c3_sel, c4_sel, c5_sel, c6_sel, c7_sel;

  // First 4-bit Ripple Carry Adder
  RCA4 rca0(.sum(sum0), .cout(c1), .a(a[3:0]), .b(b[3:0]), .cin(1'b0));
  RCA4 rca1(.sum(sum1), .cout(c2), .a(a[3:0]), .b(b[3:0]), .cin(1'b1));

  // Select the correct sum and carry out
  assign {c1_sel, sum[3:0]} = c1 ? {c2, sum1} : {c1, sum0};

  // Second 4-bit Ripple Carry Adder
  RCA4 rca2(.sum(sum2), .cout(c3), .a(a[7:4]), .b(b[7:4]), .cin(1'b0));
  RCA4 rca3(.sum(sum3), .cout(c4), .a(a[7:4]), .b(b[7:4]), .cin(1'b1));

  // Select the correct sum and carry out
  assign {cout, sum[7:4]} = c1_sel ? {c4, sum3} : {c3, sum2};

endmodule

// 4-bit Ripple Carry Adder
module RCA4(output [3:0] sum, output cout, input [3:0] a, b, input cin);

  wire [3:0] p, g, c;

  // Generate Propagate and Generate signals
  assign p = a ^ b;
  assign g = a & b;

  // Ripple Carry Logic
  assign c[0] = cin;
  assign c[1] = g[0] | (p[0] & c[0]);
  assign c[2] = g[1] | (p[1] & c[1]);
  assign c[3] = g[2] | (p[2] & c[2]);

  // Sum and Carry Out
  assign sum = p ^ c;
  assign cout = g[3] | (p[3] & c[3]);

endmodule