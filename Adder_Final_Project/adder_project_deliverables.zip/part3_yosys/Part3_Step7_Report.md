# Part 3 Step 7: Verification of the Optimized Design

## Functional Simulation Results
### area
- Compile OK: True
- Simulation command executed: True
- Final functional status: PASS
- Compile command: iverilog -g2012 -o /content/part3_yosys/rca8_area/best_adder_sim.out /content/part3_yosys/rca8_area/best_adder.v /content/part3_yosys/rca8_area/best_adder_tb.v
- Simulation command: vvp /content/part3_yosys/rca8_area/best_adder_sim.out

### delay
- Compile OK: True
- Simulation command executed: True
- Final functional status: FAIL
- Compile command: iverilog -g2012 -o /content/part3_yosys/rca8_delay/best_adder_sim.out /content/part3_yosys/rca8_delay/best_adder.v /content/part3_yosys/rca8_delay/best_adder_tb.v
- Simulation command: vvp /content/part3_yosys/rca8_delay/best_adder_sim.out

### balanced
- Compile OK: True
- Simulation command executed: True
- Final functional status: PASS
- Compile command: iverilog -g2012 -o /content/part3_yosys/rca8_balanced/best_adder_sim.out /content/part3_yosys/rca8_balanced/best_adder.v /content/part3_yosys/rca8_balanced/best_adder_tb.v
- Simulation command: vvp /content/part3_yosys/rca8_balanced/best_adder_sim.out

## Equivalence Checking Results
### area
- PASS: True
- Command: yosys -s /content/part3_yosys/rca8_area/equiv_check.ys
- Log file: /content/part3_yosys/rca8_area/equiv_check.log

### delay
- PASS: False
- Command: yosys -s /content/part3_yosys/rca8_delay/equiv_check.ys
- Log file: /content/part3_yosys/rca8_delay/equiv_check.log

### balanced
- PASS: True
- Command: yosys -s /content/part3_yosys/rca8_balanced/equiv_check.ys
- Log file: /content/part3_yosys/rca8_balanced/equiv_check.log

## Mode-by-Mode Assessment
- area mode: accepted
- delay mode: not accepted
- balanced mode: accepted

## Conclusion
The following optimized designs are accepted after Step 7 verification: area, balanced.
The delay-mode design failed functional simulation, so it is rejected regardless of its PPA improvement.
The area-mode and balanced-mode designs passed functional simulation. Their final acceptance depends on the updated SAT-based equivalence checking results.