// Carry Select Adder - 8 bits
module gate(output [7:0] sum, output cout, input [7:0] a, b);

  wire [3:0] sum0, sum1, sum2, sum3;
  wire c1, c2, c3, c4, c5, c6, c7, c8;
  wire c1_sel, c2_sel, c3_sel, c4_sel;

  // First 4-bit Ripple Carry Adder
  RCA4 rca0(sum0, c1, a[3:0], b[3:0], 1'b0);
  RCA4 rca1(sum1, c2, a[3:0], b[3:0], 1'b1);

  // Carry Select Logic for first 4 bits
  assign {c1_sel, sum[3:0]} = c1 ? {c2, sum1} : {c1, sum0};

  // Second 4-bit Ripple Carry Adder
  RCA4 rca2(sum2, c3, a[7:4], b[7:4], 1'b0);
  RCA4 rca3(sum3, c4, a[7:4], b[7:4], 1'b1);

  // Carry Select Logic for second 4 bits
  assign {cout, sum[7:4]} = c1_sel ? {c4, sum3} : {c3, sum2};

endmodule

// 4-bit Ripple Carry Adder
module RCA4(output [3:0] sum, output cout, input [3:0] a, b, input cin);

  wire [3:1] c;

  gate_FA fa0(sum[0], c[1], a[0], b[0], cin);
  gate_FA fa1(sum[1], c[2], a[1], b[1], c[1]);
  gate_FA fa2(sum[2], c[3], a[2], b[2], c[2]);
  gate_FA fa3(sum[3], cout, a[3], b[3], c[3]);

endmodule

// Full Adder
module gate_FA(output sum, cout, input a, b, cin);

  assign sum = a ^ b ^ cin;
  assign cout = (a & b) | (b & cin) | (a & cin);

endmodule