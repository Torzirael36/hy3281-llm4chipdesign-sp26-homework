// Hybrid Carry Lookahead Adder - Optimized for Delay
module RCA8(output [7:0] sum, output cout, input [7:0] a, b);

  wire [7:0] p, g;
  wire [7:0] c;

  // Generate Propagate and Generate signals
  assign p = a ^ b; // Propagate
  assign g = a & b; // Generate

  // Carry Lookahead Logic for first 4 bits
  assign c[0] = 0;
  assign c[1] = g[0] | (p[0] & c[0]);
  assign c[2] = g[1] | (p[1] & c[1]);
  assign c[3] = g[2] | (p[2] & c[2]);
  assign c[4] = g[3] | (p[3] & c[3]);

  // Carry Lookahead Logic for next 4 bits
  wire c4;
  assign c4 = g[3] | (p[3] & c[3]);
  assign c[5] = g[4] | (p[4] & c4);
  assign c[6] = g[5] | (p[5] & c[5]);
  assign c[7] = g[6] | (p[6] & c[6]);
  assign cout = g[7] | (p[7] & c[7]);

  // Sum
  assign sum = p ^ c;

endmodule