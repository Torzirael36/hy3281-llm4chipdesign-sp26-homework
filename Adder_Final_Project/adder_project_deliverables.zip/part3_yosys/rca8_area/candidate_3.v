// Full Adder using NAND gates
module FA(output sum, cout, input a, b, cin);
  wire n1, n2, n3, n4, n5, n6, n7, n8;
  
  nand (n1, a, b);
  nand (n2, a, n1);
  nand (n3, b, n1);
  nand (n4, n2, n3); // a XOR b
  
  nand (n5, n4, cin);
  nand (n6, n4, n5);
  nand (n7, cin, n5);
  nand (sum, n6, n7); // (a XOR b) XOR cin
  
  nand (n8, n1, n5);
  nand (cout, n8, n8); // (a AND b) OR ((a XOR b) AND cin)
endmodule

// Ripple Carry Adder - 8 bits
module RCA8(output [7:0] sum, output cout, input [7:0] a, b);
  
  wire [6:0] c;
  
  FA fa0(sum[0], c[0], a[0], b[0], 1'b0);
  FA fa1(sum[1], c[1], a[1], b[1], c[0]);
  FA fa2(sum[2], c[2], a[2], b[2], c[1]);
  FA fa3(sum[3], c[3], a[3], b[3], c[2]);
  FA fa4(sum[4], c[4], a[4], b[4], c[3]);
  FA fa5(sum[5], c[5], a[5], b[5], c[4]);
  FA fa6(sum[6], c[6], a[6], b[6], c[5]);
  FA fa7(sum[7], cout, a[7], b[7], c[6]);
  
endmodule