module best_adder_tb;

  reg  [7:0] a, b;
  wire [7:0] sum;
  wire cout;

  reg  [8:0] expected;
  integer total_tests, pass_count, fail_count;
  integer i;

  // optimized design is expected to keep the same top module name
  RCA8 dut(.sum(sum), .cout(cout), .a(a), .b(b));

  task run_test;
    input [7:0] ta, tb;
    begin
      a = ta;
      b = tb;
      #1;
      expected = ta + tb;
      total_tests = total_tests + 1;

      if ({cout, sum} !== expected) begin
        fail_count = fail_count + 1;
        $display("FAIL: a=%b b=%b | got cout,sum=%b_%b | expected=%b_%b",
                 a, b, cout, sum, expected[8], expected[7:0]);
      end else begin
        pass_count = pass_count + 1;
        $display("PASS: a=%b b=%b | cout,sum=%b_%b",
                 a, b, cout, sum);
      end
    end
  endtask

  initial begin
    $dumpfile("best_adder_tb.vcd");
    $dumpvars(0, best_adder_tb);

    total_tests = 0;
    pass_count = 0;
    fail_count = 0;

    // directed tests
    run_test(8'b00000000, 8'b00000000);
    run_test(8'b00000001, 8'b00000001);
    run_test(8'b11111111, 8'b00000001);
    run_test(8'b11111111, 8'b11111111);
    run_test(8'b10101010, 8'b01010101);
    run_test(8'b11110000, 8'b00001111);
    run_test(8'b10000000, 8'b10000000);
    run_test(8'b01111111, 8'b00000001);
    run_test(8'b11001100, 8'b00110011);
    run_test(8'b11100011, 8'b00011101);

    // random tests
    for (i = 0; i < 50; i = i + 1) begin
      run_test($random, $random);
    end

    $display("========================================");
    $display("BEST ADDER FUNCTIONAL TEST SUMMARY");
    $display("Total tests: %0d", total_tests);
    $display("Pass count : %0d", pass_count);
    $display("Fail count : %0d", fail_count);
    if (fail_count == 0)
      $display("FINAL STATUS: PASS");
    else
      $display("FINAL STATUS: FAIL");
    $display("========================================");

    $finish;
  end

endmodule
