# RCA8 Multi-Mode Optimization Summary

| Mode | Cell Count | Area (um^2) | Delay (ps) |
|---|---:|---:|---:|
| area | 40 | 53.2 | 74.83 |
| delay | 90 | 129.808 | 70.84 |
| balanced | 40 | 61.712 | 37.54 |