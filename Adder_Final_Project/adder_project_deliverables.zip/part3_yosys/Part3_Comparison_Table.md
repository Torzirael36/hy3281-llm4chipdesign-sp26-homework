# Part 3 Comparison Table

| Starting Architecture | Optimization Mode | Final Cells | Final Area (um^2) | Final Delay (ps) |
|---|---|---:|---:|---:|
| RCA8 | area | 40 | 53.2 | 74.83 |
| RCA8 | delay | 90 | 129.808 | 70.84 |
| RCA8 | balanced | 40 | 61.712 | 37.54 |