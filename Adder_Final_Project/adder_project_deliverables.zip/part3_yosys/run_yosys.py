\
import subprocess
import re
import json
from pathlib import Path

def parse_stats(log: str):
    ppa = {
        "area_um2": None,
        "cell_count": None,
        "logic_levels": None,
        "delay_ps": None
    }

    # Area
    m = re.search(r'Chip area for top module .*?:\s*([\d.]+)', log)
    if m:
        ppa["area_um2"] = float(m.group(1))
    else:
        m = re.search(r'Chip area for module .*?:\s*([\d.]+)', log)
        if m:
            ppa["area_um2"] = float(m.group(1))

    # Hierarchical total cell count
    hierarchy_block = re.search(
        r'=== design hierarchy ===(.*?)Chip area for top module',
        log,
        flags=re.DOTALL
    )
    if hierarchy_block:
        m = re.search(r'Number of cells:\s+(\d+)', hierarchy_block.group(1))
        if m:
            ppa["cell_count"] = int(m.group(1))

    if ppa["cell_count"] is None:
        m = re.search(r'Number of cells:\s+(\d+)', log)
        if m:
            ppa["cell_count"] = int(m.group(1))

    # Logic levels (best effort)
    patterns = [
        r'Longest topological path.*?\((\d+)\s+levels?\)',
        r'logic levels?\s*[:=]\s*(\d+)',
        r'\blev\s*=\s*(\d+)\b'
    ]
    for pat in patterns:
        m = re.search(pat, log, flags=re.IGNORECASE | re.DOTALL)
        if m:
            ppa["logic_levels"] = int(m.group(1))
            break

    # Delay in ps
    m = re.search(r'Delay\s*=\s*([\d.]+)\s*ps', log)
    if m:
        ppa["delay_ps"] = float(m.group(1))

    return ppa

def synthesize(verilog_file, top_module, template_script='synth_adder.ys'):
    verilog_path = Path(verilog_file).resolve()
    template_path = Path(template_script).resolve()
    resolved_script = Path("synth_adder_resolved.ys").resolve()

    template = template_path.read_text()
    script_text = (
        template
        .replace("__ADDER_FILE__", str(verilog_path))
        .replace("__TOP_MODULE__", top_module)
    )
    resolved_script.write_text(script_text)

    result = subprocess.run(
        ['yosys', '-s', str(resolved_script)],
        capture_output=True,
        text=True
    )

    log = (result.stdout or "") + (result.stderr or "")
    Path("yosys_last_run.log").write_text(log)

    ppa = parse_stats(log)
    ppa["returncode"] = result.returncode
    ppa["log_file"] = str(Path("yosys_last_run.log").resolve())
    ppa["resolved_script"] = str(resolved_script)

    return ppa

if __name__ == '__main__':
    import sys

    if len(sys.argv) < 3:
        print("Usage: python run_yosys.py <verilog_file> <top_module>")
        raise SystemExit(1)

    ppa = synthesize(sys.argv[1], sys.argv[2])
    print(json.dumps(ppa, indent=2))
