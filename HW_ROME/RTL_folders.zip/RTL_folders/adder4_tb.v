`timescale 1ns/1ps
module adder4_tb;
  reg  [3:0] a, b;
  reg        cin;
  wire [3:0] sum;
  wire       cout;

  adder4 dut(.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

  integer aa, bb, cc;
  reg [4:0] exp;

  initial begin
    for (cc=0; cc<2; cc=cc+1) begin
      cin = cc;
      for (aa=0; aa<16; aa=aa+1)
        for (bb=0; bb<16; bb=bb+1) begin
          a = aa[3:0]; b = bb[3:0];
          #1;
          exp = a + b + cin;
          if (sum !== exp[3:0] || cout !== exp[4]) begin
            $display("FAIL: a=%0d b=%0d cin=%0d sum=%0d exp=%0d cout=%0d exp=%0d",
                     a,b,cin,sum,exp[3:0],cout,exp[4]);
            $finish;
          end
        end
    end
    $display("passed!");
    $finish;
  end
endmodule
