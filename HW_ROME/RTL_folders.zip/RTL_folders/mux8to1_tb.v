`timescale 1ns/1ps
module mux8to1_tb;
  reg  [2:0] sel;
  reg  [7:0] in;
  wire out;

  mux8to1 dut(.sel(sel), .in(in), .out(out));

  integer v, s;
  reg exp;

  initial begin
    for (v = 0; v < 256; v = v + 1)
      for (s = 0; s < 8; s = s + 1) begin
        in = v[7:0];
        sel = s[2:0];
        #1;
        exp = in[sel];
        if (out !== exp) begin
          $display("FAIL: in=%b sel=%0d out=%b exp=%b", in, sel, out, exp);
          $finish;
        end
      end
    $display("passed!");
    $finish;
  end
endmodule
