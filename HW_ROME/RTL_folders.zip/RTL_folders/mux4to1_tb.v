`timescale 1ns/1ps
module mux4to1_tb;
  reg  [1:0] sel;
  reg  [3:0] in;
  wire out;

  mux4to1 dut(.sel(sel), .in(in), .out(out));

  integer v, s;
  reg exp;

  initial begin
    for (v = 0; v < 16; v = v + 1)
      for (s = 0; s < 4; s = s + 1) begin
        in = v[3:0];
        sel = s[1:0];
        #1;
        exp = in[sel];
        if (out !== exp) begin
          $display("FAIL: in=%b sel=%0d out=%b exp=%b", in, sel, out, exp);
          $finish;
        end
      end
    $display("passed!");
    $finish;
  end
endmodule
