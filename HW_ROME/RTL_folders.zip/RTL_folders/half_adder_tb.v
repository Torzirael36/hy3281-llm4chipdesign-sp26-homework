`timescale 1ns/1ps
module half_adder_tb;
  reg a, b;
  wire sum, carry;

  half_adder dut(.a(a), .b(b), .sum(sum), .carry(carry));

  integer i;
  reg exp_sum, exp_carry;

  initial begin
    for (i=0; i<4; i=i+1) begin
      {a,b} = i[1:0];
      #1;
      exp_sum   = a ^ b;
      exp_carry = a & b;
      if (sum !== exp_sum || carry !== exp_carry) begin
        $display("FAIL: a=%0d b=%0d sum=%0d exp=%0d carry=%0d exp=%0d",
                 a,b,sum,exp_sum,carry,exp_carry);
        $finish;
      end
    end
    $display("passed!");
    $finish;
  end
endmodule
