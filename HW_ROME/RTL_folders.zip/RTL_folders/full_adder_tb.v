`timescale 1ns/1ps
module full_adder_tb;
  reg a, b, cin;
  wire sum, cout;

  full_adder dut(.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

  integer i;
  reg [1:0] exp;

  initial begin
    for (i=0; i<8; i=i+1) begin
      {a,b,cin} = i[2:0];
      #1;
      exp = a + b + cin;
      if (sum !== exp[0] || cout !== exp[1]) begin
        $display("FAIL: a=%0d b=%0d cin=%0d sum=%0d exp=%0d cout=%0d exp=%0d",
                 a,b,cin,sum,exp[0],cout,exp[1]);
        $finish;
      end
    end
    $display("passed!");
    $finish;
  end
endmodule
