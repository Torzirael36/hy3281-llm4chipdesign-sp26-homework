`timescale 1ns/1ps
module mux2to1_tb;
  reg in1, in2, select;
  wire out;

  mux2to1 dut(.in1(in1), .in2(in2), .select(select), .out(out));

  integer a, b, s;
  reg exp;

  initial begin
    for (a = 0; a < 2; a = a + 1)
      for (b = 0; b < 2; b = b + 1)
        for (s = 0; s < 2; s = s + 1) begin
          in1 = a; in2 = b; select = s;
          #1;
          exp = (select) ? in2 : in1;
          if (out !== exp) begin
            $display("FAIL: in1=%0d in2=%0d sel=%0d out=%0d exp=%0d",
                     in1,in2,select,out,exp);
            $finish;
          end
        end
    $display("passed!");
    $finish;
  end
endmodule
