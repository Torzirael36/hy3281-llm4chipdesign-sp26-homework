`timescale 1ns/1ps
module adder8_tb;
  reg  [7:0] a, b;
  reg        cin;
  wire [7:0] sum;
  wire       cout;

  adder8 dut(.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

  integer t;
  reg [8:0] exp;

  initial begin
    // fixed seeds
    cin = 0;
    for (t=0; t<200; t=t+1) begin
      a   = $random;
      b   = $random;
      cin = $random & 1;
      #1;
      exp = a + b + cin;
      if (sum !== exp[7:0] || cout !== exp[8]) begin
        $display("FAIL: a=%0d b=%0d cin=%0d sum=%0d exp=%0d cout=%0d exp=%0d",
                 a,b,cin,sum,exp[7:0],cout,exp[8]);
        $finish;
      end
    end
    $display("passed!");
    $finish;
  end
endmodule
